// import React from 'react';
// import Image from 'next/image';
// import { Button } from '@mui/material';
// import styles from '../../../pages/treasury/index.module.scss'; // Create a separate CSS module for this component

// const FullScreenGallery = ({ item, closeGallery }) => {
//   return (
//     <div className={styles.fullScreenContainer}>
//       <Button onClick={closeGallery}>Close</Button>
//       {/* Display the image and any other content you want */}
//       <Image src={item.img} alt={item.title} layout="fill" objectFit="cover" />
//     </div>
//   );
// };

// export default FullScreenGallery;