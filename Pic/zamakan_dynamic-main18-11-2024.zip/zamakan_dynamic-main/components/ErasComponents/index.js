export { default as ErasPlacesSlider } from "../ErasComponents/ErasPlacesSlider";
