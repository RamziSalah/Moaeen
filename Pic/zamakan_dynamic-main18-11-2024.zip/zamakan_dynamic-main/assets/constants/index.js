import imgs from "./imgs";
export { imgs };
