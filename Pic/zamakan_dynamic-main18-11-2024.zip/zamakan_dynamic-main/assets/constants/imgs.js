import burgerIcon from "../burgerIcon.svg";
import Feather_big from "../Feather_big.svg";

export default {
  burgerIcon,
  Feather_big,
};
