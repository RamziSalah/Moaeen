import React from 'react'

const burgerIcon = () => {
  return (
    <>
      <svg width="19" height="14" viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M1.39014 1H17.3901M1.39014 7H17.3901M1.39014 13H17.3901" stroke="#11292F" stroke-width="2" stroke-linecap="round" />
      </svg>
    </>
  )
}

export default burgerIcon