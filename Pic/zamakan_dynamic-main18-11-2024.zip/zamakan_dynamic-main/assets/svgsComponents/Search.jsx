import React from 'react'

const Search = () => {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M8.42078 1.57227C12.2029 1.57227 15.2695 4.63817 15.2695 8.42103C15.2695 12.2039 12.2029 15.2698 8.42078 15.2698C4.63793 15.2698 1.57202 12.2039 1.57202 8.42103C1.57202 4.63817 4.63793 1.57227 8.42078 1.57227Z" stroke="#11292F" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
      <line x1="13.732" y1="13.4004" x2="16.3171" y2="15.9856" stroke="#11292F" stroke-width="1.6" stroke-linecap="round" />
    </svg>
  )
}

export default Search