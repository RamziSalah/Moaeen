﻿$(document).on("keypress", ".PassReg", function (event) {
    var ew = event.which;
    if (48 <= ew && ew <= 57)
        return true;
    if (65 <= ew && ew <= 90)
        return true;
    if (97 <= ew && ew <= 122)
        return true;
    return false;
});

$(document).on("click", "#LoginBtn", function (e) {
    e.preventDefault();

    var email = $("#LEmail").val();
    var password = $("#LPassword").val();

    if (email.trim() != "" && password.trim() != "") {

        var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
        if (!testEmail.test(email.trim())) {
            swal("", MsgEmailError);
            return;
        }

        var model = {
            Email: email,
            Password: password,
        };

        myApp.showPreloader();
        $.ajax({
            type: "POST",
            url: '/Account/Login',
            async: true,
            data: model,
            success: function (result) {
                myApp.hidePreloader();
                if (result == "1") {
                    document.location.href = "/Home/Index";
                }
                else if (result.sts == "1") {
                    document.location.href = result.url;
                }
                else if (result == "-2") {
                    document.location.href = "/Account/Confirm";
                }
                else {
                    swal("", result);
                }
            },
            error: function (xhr) {
                myApp.hidePreloader();
                jQuery.gritter.add({
                    title: MsgErrorText,
                    text: MsgErrorTryAgainContactAdmin,
                    class_name: 'growl-warning',
                    image: '/img/screen.png',
                    sticky: false,
                    time: '1500'
                });
            }
        });
    }
    else {
        swal("", MsgFillAllFields);
    }
});

$(document).on("click", "#ConfirmBtn", function (e) {
    e.preventDefault();

    var email = $("#LEmail").val();
    var password = $("#LPassword").val();

    if (email.trim() != "" && password.trim() != "") {

        var model = {
            Email: email,
            Password: password,
        };

        myApp.showPreloader();
        $.ajax({
            type: "POST",
            url: '/Account/Confirm',
            async: true,
            data: model,
            success: function (result) {
                myApp.hidePreloader();
                if (result == "1") {
                    document.location.href = "/Home/Index";
                }
                else {
                    swal("", result);
                }
            },
            error: function (xhr) {
                myApp.hidePreloader();
                jQuery.gritter.add({
                    title: MsgErrorText,
                    text: MsgErrorTryAgainContactAdmin,
                    class_name: 'growl-warning',
                    image: '/img/screen.png',
                    sticky: false,
                    time: '1500'
                });
            }
        });
    }
    else {
        swal("", MsgFillAllFields);
    }
});
$(document).on("click", "#ResetPasswordBtn", function (e) {
    e.preventDefault();

    var email = $("#LEmail").val();

    if (email.trim() != "") {

        var model = {
            Email: email
        };

        myApp.showPreloader();
        $.ajax({
            type: "POST",
            url: '/Account/ResetPassword',
            async: true,
            data: model,
            success: function (result) {
                myApp.hidePreloader();
                if (result == "1") {
                    document.location.href = "/Account/ChangePassword";
                }
                else {
                    swal("", result);
                }
            },
            error: function (xhr) {
                myApp.hidePreloader();
                jQuery.gritter.add({
                    title: MsgErrorText,
                    text: MsgErrorTryAgainContactAdmin,
                    class_name: 'growl-warning',
                    image: '/img/screen.png',
                    sticky: false,
                    time: '1500'
                });
            }
        });
    }
    else {
        swal("", MsgFillAllFields);
    }
});
$(document).on("click", "#ChangePasswordBtn", function (e) {
    e.preventDefault();

    var REmail = $("#LEmail").val();
    var RPassword = $("#LPassword").val();
    var RRPassword = $("#LRPassword").val();

    if (REmail.trim() != "" && RPassword.trim() != "" && RRPassword.trim() != "") {
        if (RPassword.trim() != RRPassword.trim()) {
            swal("", MsgPasswordMatch);
            return;
        }
        var model = {
            Email: REmail,
            Password: RPassword,
        };


        myApp.showPreloader();
        $.ajax({
            type: "POST",
            url: '/Account/ChangePassword',
            async: true,
            data: model,
            success: function (result) {
                myApp.hidePreloader();
                if (result == "1") {
                    swal("", ForgetText);
                    setTimeout(function () {
                        document.location.href = "/Account/Login";
                    }, 3000);
                }
                else {
                    swal("", result);
                }
            },
            error: function (xhr) {
                myApp.hidePreloader();
                jQuery.gritter.add({
                    title: MsgErrorText,
                    text: MsgErrorTryAgainContactAdmin,
                    class_name: 'growl-warning',
                    image: '/img/screen.png',
                    sticky: false,
                    time: '1500'
                });
            }
        });
    }
    else {
        swal("", MsgFillAllFields);
    }
});
$(document).on("click", "#ResendCodeAgain", function (e) {
    e.preventDefault();
    myApp.showPreloader();
    $.ajax({
        url: "/Account/ConfirmMobileCodeAgain",
        async: true,
        success: function (data) {
            myApp.hidePreloader();
            swal("", data);
        }
    });
});
$(document).on("click", "#ResendCodeAgain2", function (e) {
    e.preventDefault();
    myApp.showPreloader();
    $.ajax({
        url: "/Account/ConfirmMobileCodeAgain2?email=" + $(this).attr("name"),
        async: true,
        success: function (data) {
            myApp.hidePreloader();
            swal("", data);
        }
    });
});



$(document).on("click", "#RegisterBTN", function (e) {
    e.preventDefault();

    var RName = $("#RName").val();
    var REmail = $("#REmail").val();
    var RPassword = $("#RPassword").val();
    var RRPassword = $("#RRPassword").val();
    var from = $("#organization").val();

    if (RName.trim() != "" && REmail.trim() != "" && RPassword.trim() != "" && RRPassword.trim() != "") {
        if (RPassword.trim() != RRPassword.trim()) {
            swal("", MsgPasswordMatch);
            return;
        }
        var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
        if (!testEmail.test(REmail.trim())) {
            swal("", MsgEmailError);
            return;
        }
        var model = {
            Email: REmail,
            ClientName: RName,
            Password: RPassword,
            ClientTypeIdFk: from
        };

        myApp.showPreloader();
        $.ajax({
            type: "POST",
            url: '/Account/Signup',
            async: true,
            data: model,
            success: function (result) {
                myApp.hidePreloader();
                if (result == "1") {
                    document.location.href = "/Account/Confirm";
                }
                else {
                    swal("", result);
                }
            },
            error: function (xhr) {
                myApp.hidePreloader();
                jQuery.gritter.add({
                    title: MsgErrorText,
                    text: MsgErrorTryAgainContactAdmin,
                    class_name: 'growl-warning',
                    image: '/img/screen.png',
                    sticky: false,
                    time: '1500'
                });
            }
        });
    }
    else {
        swal("", MsgFillAllFields);
    }
});

$(document).on("keyup", ".EnterHere", function (event) {
    // Number 13 is the "Enter" key on the keyboard
    if (event.keyCode === 13) {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        $("#RegisterBTN").click();
    }
});

$(document).on("keyup", ".EnterHere2", function (event) {
    // Number 13 is the "Enter" key on the keyboard
    if (event.keyCode === 13) {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        $("#LoginBtn").click();
    }
});

$(document).on("keyup", ".EnterHere3", function (event) {
    // Number 13 is the "Enter" key on the keyboard
    if (event.keyCode === 13) {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        $("#ConfirmBtn").click();
    }
});
$(document).on("keyup", ".EnterHere4", function (event) {
    // Number 13 is the "Enter" key on the keyboard
    if (event.keyCode === 13) {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        $("#ResetPasswordBtn").click();
    }
});
$(document).on("keyup", ".EnterHere5", function (event) {
    // Number 13 is the "Enter" key on the keyboard
    if (event.keyCode === 13) {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        $("#ChangePasswordBtn").click();
    }
});
