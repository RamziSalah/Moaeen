﻿// On before slide change
function ChangeScreen(Sort = false) {
    if (Sort == true && correct_Ans == 0) {
        Sort = false;
    }
    correct_Ans = 1;
    var index = $(".slider-timeline_item.is-active").data("slick-index");
    if (Number(index) >= 0) {
        if ($(".slider-timeline_item[data-slick-index='" + (Number(index)) + "']").hasClass("AfterCurrentSlideHere")) {
            $(".slider-timeline_item[data-slick-index='" + (Number(index)) + "']").removeClass("AfterCurrentSlideHere");
            $(".slider-timeline_item[data-slick-index='" + (Number(index)) + "']").addClass("CurrentSlideHere");

            if (Number(index) + 1 <= $(".slider-timeline_item").length - 1 && $(".slider-timeline_item[data-slick-index='" + (Number(index) + 1) + "']").hasClass("FutureSlideHere")) {
                $(".slider-timeline_item[data-slick-index='" + (Number(index) + 1) + "']").removeClass("FutureSlideHere");
                $(".slider-timeline_item[data-slick-index='" + (Number(index) + 1) + "']").addClass("AfterCurrentSlideHere");
            }
        }
        if (Number(index) - 1 >= 0 && $(".slider-timeline_item[data-slick-index='" + (Number(index) - 1) + "']").hasClass("CurrentSlideHere")) {
            $(".slider-timeline_item[data-slick-index='" + (Number(index) - 1) + "']").removeClass("CurrentSlideHere");
            $(".slider-timeline_item[data-slick-index='" + (Number(index) - 1) + "']").addClass("FinishedSlideHere");
            //save it as finished
            $.ajax({
                type: "POST",
                url: '/Session/MarkScreenFinished',
                async: true,
                data: {
                    Id: $(".slider-timeline_item[data-slick-index='" + (Number(index) - 1) + "']").attr("name"),
                    Sort: (Sort == true) ? 1 : 0
                },
                success: function (result) {

                },
                error: function (xhr) {
                    jQuery.gritter.add({
                        title: MsgErrorText,
                        text: MsgErrorTryAgainContactAdmin,
                        class_name: 'growl-warning',
                        image: '/img/screen.png',
                        sticky: false,
                        time: '1500'
                    });
                }
            });
        }
        else if ($(".slick-slide.slick-current[data-slick-index='" + (Number(index)) + "']").find(".Ans_Check").length > 0) {
            $.ajax({
                type: "POST",
                url: '/Session/MarkScreenFinished',
                async: true,
                data: {
                    Id: $(".slider-timeline_item[data-slick-index='" + (Number(index) - 1) + "']").attr("name"),
                    Sort: (Sort == true) ? 1 : 0
                },
                success: function (result) {

                },
                error: function (xhr) {
                    jQuery.gritter.add({
                        title: MsgErrorText,
                        text: MsgErrorTryAgainContactAdmin,
                        class_name: 'growl-warning',
                        image: '/img/screen.png',
                        sticky: false,
                        time: '1500'
                    });
                }
            });
        }
    }
    if ($(".slider-timeline_item[data-slick-index='" + (Number(index)) + "']").hasClass("EndSlideHere") && $(".slider-timeline_item[data-slick-index='" + (Number(index) - 1) + "']").hasClass("FinishedSlideHere")) {
        //save topic finished
        $(".GiftSection").css("display", "none");
        $(".confetti").css("display", "block");
        setTimeout(function () {
            $(".confetti").css("display", "none");
        }, 2000);

        $.ajax({
            type: "POST",
            url: '/Session/MarkTopicFinished',
            async: true,
            data: {
                Id: $(".slider-timeline_item[data-slick-index='" + (Number(index) - 1) + "']").attr("name")
            },
            success: function (result) {
                if (result.id != 0) {
                    $(".FinalThankTxt").html(result.text);
                    $(".FinalThankTxt").css("display", "block");
                    if (result.id == 2) {
                        $(".GiftSection").html(result.cert);
                        $(".GiftSection").css("display", "block");
                    }
                    else {
                        if (result.cert != undefined) {
                            $(".GiftSection").html(result.cert);
                            $(".GiftSection").css("display", "block");
                        }
                    }
                    if (result.parentid != undefined) {
                        $(".GiftSection").attr("name", result.parentid);
                        //document.location.href = "/Session/GetCert?ParentId=" + result.parentid;
                    }
                    $('.slider-single').slick('setPosition');
                }
            },
            error: function (xhr) {
                jQuery.gritter.add({
                    title: MsgErrorText,
                    text: MsgErrorTryAgainContactAdmin,
                    class_name: 'growl-warning',
                    image: '/img/screen.png',
                    sticky: false,
                    time: '1500'
                });
            }
        });
    }
}